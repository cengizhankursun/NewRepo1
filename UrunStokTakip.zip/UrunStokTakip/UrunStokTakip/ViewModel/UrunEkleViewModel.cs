﻿using UrunStokTakip.Models;

namespace UrunStokTakip.ViewModel
{
    public class UrunEkleViewModel
    {
        public  Urun YeniUrun {  get; set; }

        public List<string> Kategoriler { get; set; }

        public List<Urun> Urunler { get; set; }
    }
}
