using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using UrunStokTakip.Models;
using UrunStokTakip.ViewModel;

namespace UrunStokTakip.Controllers
{
    public class HomeController : Controller
    {
        private static List<Urun> urunler = new List<Urun>();
        private static int idSayaci = 1;

        public IActionResult Urun()
        {
            return View(urunler);
        }
        public IActionResult Ekle()
        {
            var vm = new UrunEkleViewModel
            {
                YeniUrun = new Urun(),
                Kategoriler = new List<string> { "G�da", "Temizlik", "Teknoloji", "K�rtasiye" }
            };
            return View(vm);
        }

        [HttpPost]

        public IActionResult Ekle(UrunEkleViewModel model)
        {
            model.YeniUrun.Id = urunler.Count + 1;
            urunler.Add(model.YeniUrun);
            return RedirectToAction("Urun");
        }

        public IActionResult Sil(int id)
        {
            var silinecek =urunler.FirstOrDefault(u => u.Id == id);
            if(silinecek != null)
            {
                urunler.Remove(silinecek);
            }
            return RedirectToAction("Urun");
        }

        public IActionResult Guncelle(int id)
        {
            var urun = urunler.FirstOrDefault(u =>u.Id == id);
            if(urun == null)
            {
                return NotFound();
            }

            var vm = new UrunEkleViewModel
            {
                YeniUrun = urun,
                Kategoriler = new List<string> { "G�da", "Temizlik", "Teknoloji", "K�rtasiye" }
            };
            return View(vm);
        }
        [HttpPost]

        public IActionResult Guncelle(UrunEkleViewModel model)
        {
            var guncel = urunler.FirstOrDefault(u => u.Id ==model.YeniUrun.Id);
            if(guncel != null)
            {
                guncel.UrunAdi = model.YeniUrun.UrunAdi;
                guncel.Miktar = model.YeniUrun.Miktar;
                guncel.Kategori = model.YeniUrun.Kategori;

            }
            return RedirectToAction("Urun");
        }






























        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
