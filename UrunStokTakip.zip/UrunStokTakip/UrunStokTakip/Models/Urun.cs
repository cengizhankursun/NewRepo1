﻿namespace UrunStokTakip.Models
{
    public class Urun
    {
        public int Id { get; set; }
        public string UrunAdi { get; set; }
        public int Miktar { get; set; }
        public string Kategori { get; set; }
    }
}
